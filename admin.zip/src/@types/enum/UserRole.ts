export enum UserRole {
  ROOT = 'root',
  ADMIN = 'admin',
  USER = 'user',
}