export type Sound = {
  id: number;
  name: string;
  image: string;
  sound: string;
};
