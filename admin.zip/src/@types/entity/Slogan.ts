export type Slogan = {
  id: number;
  title: string;
  image: string;
};
