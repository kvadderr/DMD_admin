export interface Props {
  isAuth: boolean;
}
